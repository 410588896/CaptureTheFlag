public class EntityOutOfBoundsException extends Exception{
	
	public EntityOutOfBoundsException(String s){
		super(s);
	}

}